class Global {
  static String? email;
  static String? password;
  // static String? signInEmail;
  // static String? signInPassword;
  static String? name;
  static int? age;
  static String? city;
}
